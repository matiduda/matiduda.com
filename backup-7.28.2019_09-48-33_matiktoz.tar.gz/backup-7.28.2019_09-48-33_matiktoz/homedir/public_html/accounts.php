<?php defined('AUTOMAD') or die('Direct access not permitted!');
return unserialize('a:1:{s:5:"admin";s:60:"$2y$10$RM57gDV48tEXQf0jpLKsaeoa4a2aCAcBJO4/g5lwBkq/x6pl7mJd2";}');
?>