<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
	<div class="content">
		<h1>@{ title }</h1>
		<div class="is-size-5">
			@{ textTeaser | markdown }
		</div>
	</div>
	<div class="field">
		<a href="#source" class="button is-light">Jump to Source</a>
	</div>