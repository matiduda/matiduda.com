<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
<@ snippets/header.php @>

	<div class="uk-block">
		<h1>Page not found!</h1>
		<i class="uk-icon-frown-o uk-icon-large"></i>
	</div>

<@ snippets/footer.php @>