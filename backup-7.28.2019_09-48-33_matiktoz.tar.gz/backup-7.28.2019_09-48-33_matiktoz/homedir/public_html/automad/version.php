<?php define('AM_VERSION', '1.2.5'); ?>
