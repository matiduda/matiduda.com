<@ if @{ a } or @{ b | def (1) } @>
	True
<@ end @>