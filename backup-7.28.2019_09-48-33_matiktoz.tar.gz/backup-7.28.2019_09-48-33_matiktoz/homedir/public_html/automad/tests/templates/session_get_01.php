<?php $_SESSION['data']['%sessionVar'] = 'Session Test'; ?>
@{ %sessionVar }