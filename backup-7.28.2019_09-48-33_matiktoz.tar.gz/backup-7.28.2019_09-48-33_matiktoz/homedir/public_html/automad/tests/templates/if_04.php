<@ if not @{ a } and @{ b | def (1) } @>
	True
<@ end @>