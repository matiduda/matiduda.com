<@ set { setVar1: 'Test 1', setVar2: 'Test 2' } @>
@{ setVar1 }, @{ setVar2 }